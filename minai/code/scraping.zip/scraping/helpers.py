from requests import get, RequestException
from contextlib import closing
import multiprocessing
import time
import os
import pandas as pd

def simple_get(url, max_retries=3):
    """
    Attempts to get the content at `url` by making an HTTP GET request.
    If the content-type of response is some kind of HTML/XML, return the
    text content, otherwise return None.
    Retry up to `max_retries` times on HTTP errors with a 1-second delay.
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.76 Safari/537.36'
        }
        for _ in range(max_retries):
            with closing(get(url, stream=True, headers=headers)) as resp:
                if is_good_response(resp):
                    return resp.content
                else:
                    print(f"Recieved a HTTP {resp.status_code} ERROR for {url}.")
                    print("Retrying in 1 second...")
                    time.sleep(1)
        print("-------------------------------------")
        print(f"Retrieving {url} FAILED. Visit this URL in your browser to confirm correctness.")
        print("-------------------------------------")
        return None
    except RequestException as e:
        print(f"The following error occurred during HTTP GET request to {url}: {str(e)}")
        return None

def url_to_filename(url, folder):
    """
    Transforms an URL string to a folder/filename string by replacing slashes
    with underscores.
    """
    return os.path.join(folder, f"{url.replace('https://', '').replace('/', '_')}.html")


def save_to_html(content, filename):
    """
    Saves the page content to an HTML file in the 'data' folder.
    """
    with open(filename, 'wb') as f:
        f.write(content)

def retrieve_and_store_page_content(url, folder):
    """
    Retrieves the page content for a single URL and writes it to the folder data.
    """
    filename = url_to_filename(url, folder)

    # Check if the file already exists and has content
    if os.path.exists(filename) and os.path.getsize(filename) > 0:
        return

    content = simple_get(url)
    save_to_html(content, filename)

from functools import partial

def get_multiple_page_contents(url_list, processes=20, folder='webpages'):
    """
    Retrieves the page content for a list of URLs using multiprocessing.
    By default writes the content to HTML files in the 'webpages' folder.
    """

    # Check if the folder exists, and create it if needed
    if not os.path.exists(folder):
        os.makedirs(folder)

    with multiprocessing.Pool(processes=processes) as pool:
        pool.map(partial(retrieve_and_store_page_content, folder=folder), url_list)

def is_good_response(resp):
    """
    Returns true if the response seems to be HTML, false otherwise.
    """
    content_type = resp.headers['Content-Type'].lower()
    return (resp.status_code == 200
            and content_type is not None
            and content_type.find('html') > -1)

def read_page_content_from_disk(url, folder='webpages'):
    """
    Reads the page content from a file on disk.
    """
    filename = url_to_filename(url, folder)

    if not os.path.exists(filename):
        print(f"File not found: {filename}")
        print(f"Have you scraped this URL: {url}?")
        return

    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()

        if len(content) == 0:
            print(f"{filename} is empty. Something went wrong during crawling!")

        return content

def get_movie_actors(dom):
    """
    Extracts the lead actors in a movie from a dom made from a website like
    https://www.imdb.com/title/tt0111161/.

    Returns a string with the names of all actors separated by semicolons.
    """

    div_list = dom.find_all('li', {'class': 'ipc-metadata-list__item'})

    for div in div_list:
        if div.text.startswith('Star'):
            # select the part with the actors
            links = div.find('div', {'class': 'ipc-metadata-list-item__content-container'}).find_all('a')

            # actor names are in the text of the links
            actors = [link.text for link in links]

            return ';'.join(actors)

def get_movie_languages(dom):
    """
    Extracts all languages spoken in a movie from a dom made from a website like
    https://www.imdb.com/title/tt0111161/.

    Returns a string with the languages separated by semicolons.
    """
    lang_list = dom.find('li', {'data-testid': 'title-details-languages'})

    # some movies do not have a language listed anywhere, we just skip those
    if not lang_list:
        return ''

    # find the actual list items, these contain links
    lang_list = lang_list.find_all('li')

    # collect the text for each of the language links
    languages = []
    for lang_dom_element in lang_list:
        language = lang_dom_element.find('a').text
        languages.append(language)

    return ';'.join(languages)
