"""
Author: Wouter Vrielink
Student number: NA

Scrapes the top movies webpage by IMDB for movie data, and outputs the data to
a csv.

Usage: scraper.py [-h] [-s START_YEAR] [-e END_YEAR] output
"""

from helpers import simple_get
from bs4 import BeautifulSoup
import re
import pandas as pd
from math import ceil
import argparse

def main(output_file_name, start_year, end_year):
    ### YOU WILL CHANGE THE CODE HERE

    IMDB_URL = 'https://www.imdb.com/search/title/?title_type=feature&release_date=1930-01-01,2019-12-31&num_votes=5000,&sort=user_rating,desc'

    # Load website with BeautifulSoup
    html = simple_get(IMDB_URL)
    dom = BeautifulSoup(html, 'html.parser')

    # Extract movies from website
    movies_df = extract_movies(dom)

    # Save results to output file
    movies_df.to_csv(output_file_name, index=False)

def extract_movies(dom):
    """
    Extracts a dataframe of movies from a DOM of an IMDB page like:
    https://www.imdb.com/search/title/?title_type=feature&release_date=1930-01-01,2020-12-31&num_votes=5000,&sort=user_rating,desc

    Each movie in the dataframe will get the following fields:
    - Title
    - Rating
    - Year of release
    - Runtime
    - URL
    """
    all_movie_data = []

    # Find all movie elements, and loop over them one by one, extracting data
    movies = dom.find_all("li", {"class": "ipc-metadata-list-summary-item"})
    for movie in movies:
        movie_data = extract_movie_data(movie)
        all_movie_data.append(movie_data)

    # Convert list of lists to a dataframe and set a header
    df = pd.DataFrame(all_movie_data, columns = ['title', 'rating', 'year', 'runtime', 'url'])
    return df


def extract_movie_data(movie):
    """
    Helper function that can extract the title, rating, runtime, year, and
    runtime of a function from a singular movie DOM.
    """
    # Get the element holding both the title and the link to the movie's page
    title_link = movie.find('a', {'class': 'ipc-title-link-wrapper'})

    # Movies have a ranking number in front, this is at most 3 chars long
    title = title_link.text[3:].strip()

    # Construct the full url from a local link
    url = 'https://www.imdb.com' + title_link['href']

    # Get the rating element, this also contains the number of votes
    rating_element = movie.find('span', {'class': 'ipc-rating-star'})
    rating_text = rating_element.text

    # Rating has format x.x (<#ratings>), we can remove everything after space
    rating = rating_text.split()[0]

    # Year and runtime are both in a div metadata container
    year_runtime_element = movie.find('div', {'class': 'dli-title-metadata'})

    # This element contains the year, runtime string, and a PG rating
    year_runtime_pg = year_runtime_element.find_all('span')
    year_element = year_runtime_pg[0]
    runtime_element = year_runtime_pg[1]

    year = year_element.text

    # Runtime has weird formatting where both hours and minutes are optional
    # We'll just use a function and explain the process there
    runtime = convert_runtime(runtime_element.text)

    return title, rating, year, runtime, url


def convert_runtime(runtime_string):
    """
    Converts a runtime string into a runtime in minutes. Runtime strings are
    assumed to have the following format: [<hours>h] [<minutes>m]

    Note that both hours and minutes are optional. Example inputs and their
    outputs are:
    - '2h 22m' -> 142
    - '23m' -> 23
    - '30h' -> 1800
    """
    runtime = 0

    # This str has hours, split on the h and get the amount, multiplying by 60
    if 'h' in runtime_string:
        hours = int(runtime_string.split('h')[0])
        runtime += hours * 60

    # This str has minutes, which is in the back, get the last two characters
    # before the 'm' and convert to minutes
    if 'm' in runtime_string:
        minutes = int(runtime_string[-3:-1])
        runtime += minutes

    return runtime

if __name__ == "__main__":
    # Set-up parsing command line arguments
    parser = argparse.ArgumentParser(description = "extract top N movies from IMDB")

    # Adding arguments
    parser.add_argument("output", help = "output file (csv)")
    parser.add_argument("-s", "--start_year", type=int, default = 1930, help="starting year (default: 1930)")
    parser.add_argument("-e", "--end_year",   type=int, default = 2020, help="ending year (default: 2020)")

    # Read arguments from command line
    args = parser.parse_args()

    # Run main with provide arguments
    main(args.output, args.start_year, args.end_year)
