from requests import get, RequestException
from contextlib import closing
import multiprocessing
import time
import os
import pandas as pd

def simple_get(url, max_retries=3):
    """
    Attempts to get the content at `url` by making an HTTP GET request.
    If the content-type of response is some kind of HTML/XML, return the
    text content, otherwise return None.
    Retry up to `max_retries` times on HTTP errors with a 1-second delay.
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.76 Safari/537.36'
        }
        for _ in range(max_retries):
            with closing(get(url, stream=True, headers=headers)) as resp:
                if is_good_response(resp):
                    return resp.content
                else:
                    print(f"Recieved a HTTP {resp.status_code} ERROR for {url}.")
                    print("Retrying in 1 second...")
                    time.sleep(1)
        print("-------------------------------------")
        print(f"Retrieving {url} FAILED. Visit this URL in your browser to confirm correctness.")
        print("-------------------------------------")
        return None
    except RequestException as e:
        print(f"The following error occurred during HTTP GET request to {url}: {str(e)}")
        return None

def url_to_filename(url, folder):
    """
    Transforms an URL string to a folder/filename string by replacing slashes
    with underscores.
    """
    return os.path.join(folder, f"{url.replace('https://', '').replace('/', '_')}.html")


def save_to_html(url, content, filename):
    """
    Saves the page content to an HTML file in the 'data' folder.
    """
    with open(filename, 'wb') as f:
        f.write(content)

def retrieve_and_store_page_content(url, folder):
    """
    Retrieves the page content for a single URL and writes it to the folder data.
    """
    filename = url_to_filename(url, folder)

    # Check if the file already exists and has content
    if os.path.exists(filename) and os.path.getsize(filename) > 0:
        return

    content = simple_get(url)
    save_to_html(url, content, filename)

from functools import partial

def get_page_contents_multiprocess(url_list, processes=20, folder='webpages'):
    """
    Retrieves the page content for a list of URLs using multiprocessing.
    By default writes the content to HTML files in the 'webpages' folder.
    """

    # Check if the folder exists, and create it if needed
    if not os.path.exists(folder):
        os.makedirs(folder)

    with multiprocessing.Pool(processes=20) as pool:
        pool.map(partial(retrieve_and_store_page_content, folder=folder), url_list)

def is_good_response(resp):
    """
    Returns true if the response seems to be HTML, false otherwise.
    """
    content_type = resp.headers['Content-Type'].lower()
    return (resp.status_code == 200
            and content_type is not None
            and content_type.find('html') > -1)

def read_page_content_from_disk(url, folder='webpages'):
    """
    Reads the page content from a file on disk.
    """
    filename = url_to_filename(url, folder)

    if not os.path.exists(filename):
        print(f"File not found: {filename}")
        print(f"Have you scraped this URL: {url}?")
        return

    with open(filename, 'r') as f:
        content = f.read()

        if len(content) == 0:
            print(f"{filename} is empty. Something went wrong during crawling!")

        return content
